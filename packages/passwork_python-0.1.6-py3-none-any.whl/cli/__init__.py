# This file marks the directory as a Python package
from .main import main
